#include <string>
using namespace std;
const string storyProcess[] = {
    "I ",
    "successfully moved the photos of Asahina to my computer, got caught by Haruhi afterwards and was dragged into a closed zone. I met a giant and tried my best to escape. Finally I kissed Haruhi and escaped. We watched Attack on Titan together afterwards. ",
    "Then, Asahina and I went back to 3 years ago to help Haruhi draw the mysterious symbol which means \"I am here\". Then we went to Nagato's house, slept there for 3 years and woke up just at the time after I went to past. ",
    "We struggled to make the movie The Adventures of Mikuru Asahina Episode 00 together and it turned out to be a success in Cultural Festival. Many students liked it, although I thought it was bad. ",
    "We played Blackjack and won. We got 4 computers and Stardust Crusade became an affiliate group of SOS Brigade. "
    "One month later before Christmas, Haruhi disappeared suddenly. I had almost lost all hope of life. But I found Nagato and a tip to go back to normal. I found Haruhi and Koizumi in another school, led them back to my school and found Asahina. ",
    "Nagato's program started running and sent me back to 3 years ago where I found Adult Asahina. I then went to find Haruhi and remind her not to forget me. We went to Nagato's bedroom again, got the message that it was Nagato who changed the world, got the fix program and went back to 3 years later, before Haruhi disappeared. ",
    "We found Nagato, who was the real culprit for Haruhi's disappearance. After a short struggle, I decided to inject the program into Nagato's body and make her recover the world. ",
    "However, I was almost killed by Asakura Ryoko. ",
    "I woke up in hospital, without any hurt. Haruhi slept beside me in a sleeping bag. Koizumi was peeling an apple for me. I was so impressed that everyone in SOS Brigade get together again. ",
    "After we had a Christmas party, Nagato, Asahina and I went back to the time when I was about to be killed, and saved me. "
};