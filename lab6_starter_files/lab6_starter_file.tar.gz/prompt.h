//
// Created by mike on 2021/6/23.
//

#ifndef LAB6_PROMPT_H
#define LAB6_PROMPT_H
const string WELCOME =
        "##############################################\n"\
        "#                                            #\n"\
        "#         A simple shell for Lab 6           #\n"\
        "#             I am not a bot                 #\n"\
        "#                                            #\n"\
        "##############################################\n";
#endif //LAB6_PROMPT_H
