/*
 * VE280 Lab 3, SU2021.
 * Written by Yanjun Chen
 */
 
#include <string>
const std::string help_message("Hey, I love Integers.");
const std::string add_message("This is add operation.");
const std::string small_message("This is small operation.");
const std::string no_op_message("No work to do!");



int main() {
	//TODO write your code here
	return 0;
}