#include <algorithm>
#include <iostream>
#include <string>
#include "Dlist.h"
#include "Instr.h"

int main(int argc, char *argv[])
{
    //TODO:write your code here.
    return 0;
}
